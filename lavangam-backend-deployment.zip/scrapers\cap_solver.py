def solve_captcha(image_data):
    # Dummy function for development
    print("solve_captcha called (dummy)")
    return "dummy_captcha" 