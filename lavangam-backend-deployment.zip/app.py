# AWS Elastic Beanstalk entry point
from hello_world import app

# This file is used by AWS Elastic Beanstalk to find the FastAPI app
# The app is imported from hello_world.py where ALL services are combined 